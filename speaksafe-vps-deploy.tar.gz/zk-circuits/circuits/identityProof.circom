pragma circom 2.0.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/comparators.circom";
include "../node_modules/circomlib/circuits/eddsaposeidon.circom";

/*
 * Identity Proof Circuit
 * 
 * This circuit allows users to prove they have a valid identity
 * without revealing personal information. It supports:
 * 1. Government ID verification (without revealing ID number)
 * 2. Email verification (without revealing email)
 * 3. Phone verification (without revealing phone number)
 * 4. Biometric verification (without revealing biometric data)
 */

template IdentityProof() {
    // Private inputs
    signal private input identitySecret;     // Master identity secret
    signal private input idNumber;          // Government ID number
    signal private input emailHash;         // Hash of email address
    signal private input phoneHash;         // Hash of phone number
    signal private input biometricHash;     // Hash of biometric data
    signal private input birthDate;         // Birth date (YYYYMMDD format)
    signal private input nationality;       // Nationality code
    
    // Public inputs
    signal input verificationLevel;        // Required verification level (1-4)
    signal input currentTimestamp;         // Current timestamp
    signal input challengeNonce;           // Challenge nonce from verifier
    
    // Outputs
    signal output identityCommitment;      // Commitment to identity
    signal output verificationProof;       // Proof of verification level
    signal output ageProof;               // Proof of minimum age
    signal output nationalityProof;        // Proof of nationality (if required)
    
    // Components
    component poseidon1 = Poseidon(4);
    component poseidon2 = Poseidon(3);
    component poseidon3 = Poseidon(2);
    component poseidon4 = Poseidon(5);
    
    // Age verification
    component ageCheck = GreaterEqThan(8);
    component dateValidator = ValidDate();
    
    // Verification level checks
    component levelCheck = LessEqThan(3);
    component level1 = IsEqual();
    component level2 = IsEqual();
    component level3 = IsEqual();
    component level4 = IsEqual();
    
    // Constraint: Verification level must be 1-4
    levelCheck.in[0] <== verificationLevel;
    levelCheck.in[1] <== 4;
    levelCheck.out === 1;
    
    // Set up level comparisons
    level1.in[0] <== verificationLevel;
    level1.in[1] <== 1;
    
    level2.in[0] <== verificationLevel;
    level2.in[1] <== 2;
    
    level3.in[0] <== verificationLevel;
    level3.in[1] <== 3;
    
    level4.in[0] <== verificationLevel;
    level4.in[1] <== 4;
    
    // Validate birth date format
    dateValidator.date <== birthDate;
    dateValidator.isValid === 1;
    
    // Calculate age from birth date
    signal birthYear <== birthDate \ 10000;
    signal currentYear <== currentTimestamp \ 31536000 + 1970; // Approximate year from timestamp
    signal age <== currentYear - birthYear;
    
    // Constraint: Must be at least 18 years old
    ageCheck.in[0] <== age;
    ageCheck.in[1] <== 18;
    ageProof <== ageCheck.out;
    
    // Generate identity commitment
    poseidon1.inputs[0] <== identitySecret;
    poseidon1.inputs[1] <== idNumber;
    poseidon1.inputs[2] <== emailHash;
    poseidon1.inputs[3] <== phoneHash;
    identityCommitment <== poseidon1.out;
    
    // Generate verification proof based on level
    // Level 1: Email only
    // Level 2: Email + Phone
    // Level 3: Email + Phone + ID
    // Level 4: Email + Phone + ID + Biometric
    
    signal emailValid <== IsNonZero()(emailHash);
    signal phoneValid <== IsNonZero()(phoneHash);
    signal idValid <== IsNonZero()(idNumber);
    signal biometricValid <== IsNonZero()(biometricHash);
    
    signal level1Valid <== emailValid;
    signal level2Valid <== emailValid * phoneValid;
    signal level3Valid <== emailValid * phoneValid * idValid;
    signal level4Valid <== emailValid * phoneValid * idValid * biometricValid;
    
    // Select appropriate validation based on level
    verificationProof <== level1.out * level1Valid + 
                         level2.out * level2Valid + 
                         level3.out * level3Valid + 
                         level4.out * level4Valid;
    
    // Generate nationality proof
    poseidon2.inputs[0] <== nationality;
    poseidon2.inputs[1] <== identitySecret;
    poseidon2.inputs[2] <== challengeNonce;
    nationalityProof <== poseidon2.out;
}

/*
 * Date Validation Template
 * Validates that a date is in correct YYYYMMDD format
 */
template ValidDate() {
    signal input date;
    signal output isValid;
    
    // Extract year, month, day
    signal year <== date \ 10000;
    signal month <== (date \ 100) % 100;
    signal day <== date % 100;
    
    // Validate ranges
    component yearCheck = GreaterEqThan(12);
    component monthCheck1 = GreaterEqThan(4);
    component monthCheck2 = LessEqThan(4);
    component dayCheck1 = GreaterEqThan(5);
    component dayCheck2 = LessEqThan(5);
    
    // Year must be between 1900 and 2023
    yearCheck.in[0] <== year;
    yearCheck.in[1] <== 1900;
    
    // Month must be 1-12
    monthCheck1.in[0] <== month;
    monthCheck1.in[1] <== 1;
    monthCheck2.in[0] <== month;
    monthCheck2.in[1] <== 12;
    
    // Day must be 1-31 (simplified validation)
    dayCheck1.in[0] <== day;
    dayCheck1.in[1] <== 1;
    dayCheck2.in[0] <== day;
    dayCheck2.in[1] <== 31;
    
    isValid <== yearCheck.out * monthCheck1.out * monthCheck2.out * dayCheck1.out * dayCheck2.out;
}

/*
 * Non-Zero Check Template
 */
template IsNonZero() {
    signal input in;
    signal output out;
    
    component isZero = IsZero();
    isZero.in <== in;
    out <== 1 - isZero.out;
}

/*
 * Biometric Verification Template
 * Proves biometric data matches without revealing the data
 */
template BiometricVerification() {
    signal private input biometricData;
    signal private input biometricSalt;
    signal input expectedHash;
    signal output isValid;
    
    component poseidon = Poseidon(2);
    component eq = IsEqual();
    
    // Hash the biometric data with salt
    poseidon.inputs[0] <== biometricData;
    poseidon.inputs[1] <== biometricSalt;
    
    // Compare with expected hash
    eq.in[0] <== poseidon.out;
    eq.in[1] <== expectedHash;
    
    isValid <== eq.out;
}

/*
 * Email Verification Template
 * Proves email ownership without revealing the email
 */
template EmailVerification() {
    signal private input email;
    signal private input emailNonce;
    signal input emailCommitment;
    signal input verificationCode;
    signal output isValid;
    
    component poseidon1 = Poseidon(2);
    component poseidon2 = Poseidon(2);
    component eq = IsEqual();
    
    // Generate email commitment
    poseidon1.inputs[0] <== email;
    poseidon1.inputs[1] <== emailNonce;
    
    // Verify commitment matches
    eq.in[0] <== poseidon1.out;
    eq.in[1] <== emailCommitment;
    
    // Generate verification code
    poseidon2.inputs[0] <== email;
    poseidon2.inputs[1] <== verificationCode;
    
    isValid <== eq.out;
}

// Main component
component main = IdentityProof();
