pragma circom 2.0.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/comparators.circom";
include "../node_modules/circomlib/circuits/bitify.circom";

/*
 * Anonymous Report Circuit
 * 
 * This circuit allows users to prove they have the right to submit a report
 * without revealing their identity. It ensures:
 * 1. The reporter has a valid identity secret
 * 2. The report content hash is correctly computed
 * 3. The anonymous ID is derived from the identity secret
 * 4. The reporter hasn't used this identity before (nullifier)
 */

template AnonymousReport() {
    // Private inputs (known only to the prover)
    signal private input identitySecret;      // User's secret identity
    signal private input reportContent;       // Hash of report content
    signal private input nonce;              // Random nonce for uniqueness
    signal private input reporterData;       // Additional reporter data (age, location hash, etc.)
    
    // Public inputs (known to verifier)
    signal input nullifierHash;             // Prevents double reporting with same identity
    signal input reportHash;                // Public hash of the report
    signal input timestamp;                 // Report submission timestamp
    signal input categoryCode;              // Report category (0-7)
    signal input severityLevel;             // Severity level (0-3)
    
    // Outputs
    signal output anonymousId;              // Anonymous identifier for the reporter
    signal output commitmentHash;           // Commitment to the report
    signal output validityProof;            // Proof that all constraints are satisfied
    
    // Components
    component poseidon1 = Poseidon(2);
    component poseidon2 = Poseidon(3);
    component poseidon3 = Poseidon(4);
    component poseidon4 = Poseidon(5);
    
    // Range checks
    component categoryCheck = LessEqThan(3);  // Category must be 0-7 (3 bits)
    component severityCheck = LessEqThan(2);  // Severity must be 0-3 (2 bits)
    component timestampCheck = GreaterThan(32); // Timestamp must be reasonable
    
    // Constraint: Category must be valid (0-7)
    categoryCheck.in[0] <== categoryCode;
    categoryCheck.in[1] <== 7;
    categoryCheck.out === 1;
    
    // Constraint: Severity must be valid (0-3)
    severityCheck.in[0] <== severityLevel;
    severityCheck.in[1] <== 3;
    severityCheck.out === 1;
    
    // Constraint: Timestamp must be reasonable (after 2020)
    timestampCheck.in[0] <== timestamp;
    timestampCheck.in[1] <== 1577836800; // Jan 1, 2020
    timestampCheck.out === 1;
    
    // Generate anonymous ID from identity secret and nonce
    poseidon1.inputs[0] <== identitySecret;
    poseidon1.inputs[1] <== nonce;
    anonymousId <== poseidon1.out;
    
    // Generate nullifier hash to prevent double spending
    poseidon2.inputs[0] <== identitySecret;
    poseidon2.inputs[1] <== reportContent;
    poseidon2.inputs[2] <== timestamp;
    nullifierHash === poseidon2.out;
    
    // Generate report hash commitment
    poseidon3.inputs[0] <== reportContent;
    poseidon3.inputs[1] <== categoryCode;
    poseidon3.inputs[2] <== severityLevel;
    poseidon3.inputs[3] <== timestamp;
    reportHash === poseidon3.out;
    
    // Generate commitment hash (binds all private inputs)
    poseidon4.inputs[0] <== identitySecret;
    poseidon4.inputs[1] <== reportContent;
    poseidon4.inputs[2] <== nonce;
    poseidon4.inputs[3] <== reporterData;
    poseidon4.inputs[4] <== timestamp;
    commitmentHash <== poseidon4.out;
    
    // Validity proof (ensures all constraints are met)
    validityProof <== categoryCheck.out * severityCheck.out * timestampCheck.out;
}

/*
 * Age Verification Circuit
 * Proves the reporter is above a certain age without revealing exact age
 */
template AgeVerification() {
    signal private input age;
    signal private input birthYear;
    signal input currentYear;
    signal input minimumAge;
    
    signal output isValidAge;
    
    component ageCheck = GreaterEqThan(8);
    component yearCheck = LessEqThan(12);
    
    // Calculate age from birth year
    signal calculatedAge <== currentYear - birthYear;
    
    // Constraint: calculated age must match provided age
    calculatedAge === age;
    
    // Constraint: age must be at least minimum required
    ageCheck.in[0] <== age;
    ageCheck.in[1] <== minimumAge;
    
    // Constraint: birth year must be reasonable
    yearCheck.in[0] <== birthYear;
    yearCheck.in[1] <== currentYear - 13; // Max age 13 for this check
    
    isValidAge <== ageCheck.out * yearCheck.out;
}

/*
 * Location Privacy Circuit
 * Proves the reporter is from a valid jurisdiction without revealing exact location
 */
template LocationPrivacy() {
    signal private input countryCode;
    signal private input regionCode;
    signal private input cityHash;
    
    signal input validCountries[10]; // List of valid country codes
    signal output locationProof;
    signal output locationCommitment;
    
    component poseidon = Poseidon(3);
    component countryValidator = ValidCountry(10);
    
    // Validate country is in allowed list
    countryValidator.countryCode <== countryCode;
    for (var i = 0; i < 10; i++) {
        countryValidator.validCountries[i] <== validCountries[i];
    }
    
    // Generate location commitment without revealing exact location
    poseidon.inputs[0] <== countryCode;
    poseidon.inputs[1] <== regionCode;
    poseidon.inputs[2] <== cityHash;
    locationCommitment <== poseidon.out;
    
    locationProof <== countryValidator.isValid;
}

/*
 * Helper template to validate country codes
 */
template ValidCountry(n) {
    signal input countryCode;
    signal input validCountries[n];
    signal output isValid;
    
    component eq[n];
    component sum = Sum(n);
    
    for (var i = 0; i < n; i++) {
        eq[i] = IsEqual();
        eq[i].in[0] <== countryCode;
        eq[i].in[1] <== validCountries[i];
        sum.inputs[i] <== eq[i].out;
    }
    
    // At least one country must match
    component isNonZero = IsZero();
    isNonZero.in <== sum.out;
    isValid <== 1 - isNonZero.out;
}

/*
 * Sum template for adding multiple signals
 */
template Sum(n) {
    signal input inputs[n];
    signal output out;
    
    if (n == 1) {
        out <== inputs[0];
    } else {
        component sum = Sum(n-1);
        for (var i = 0; i < n-1; i++) {
            sum.inputs[i] <== inputs[i];
        }
        out <== sum.out + inputs[n-1];
    }
}

// Main component
component main = AnonymousReport();
